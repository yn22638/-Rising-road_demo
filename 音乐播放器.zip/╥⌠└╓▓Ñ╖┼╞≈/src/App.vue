<template>
  <div id="app">
    <header>音乐台</header>
    <section>
      <ul>
        <li
          v-for="(item, index) in arr"
          :key="index"
          @click="clickMusic(item.id)"
          :class="{ sty: item.sty }"
        >
          {{ item.name }}
        </li>
      </ul>
    </section>
    <!-- <div v-if="musciUrl != ''"> -->
    <audio ref="au"  controls autoplay>
      <source ref="so" type="audio/mpeg" />
    </audio>
    <!-- </div> -->
    <!-- <div v-else> -->
    <!-- 沒選歌 -->
    <!-- </div> -->

    <footer v-text="textM"></footer>

    <button @click="clickMusic">点击</button>
  </div>
</template>

<script>
export default {
  name: "app",
  data: function () {
    return {
      bbb: false,
      sty: false,
      musciUrl: "",
      arr: [
        {
          id: "1",
          name: "七旬.",
          url: "./audio/one.mp3",
          sty: false,
        },
        {
          id: "2",
          name: "八旬.",
          url: "./audio/one.mp31",
          sty: false,
        },
        {
          id: "3",
          name: "九旬.",
          url: "./audio/one.mp31",
          sty: false,
        },
      ],
      index: "",
      textM: "当前播放的是:",
    };
  },
  methods: {
    clickMusic(e) {
      // console.log(this);
      for (var i = 0; i < this.arr.length; i++) {
        this.arr[i].sty = false;
        if (e == this.arr[i].id) {
          this.textM = "当前播放的是:";
          //   this.sty = false;
          this.arr[i].sty = true;
          this.textM += this.arr[i].name;
          this.$refs.so.src = this.arr[i].url;
          this.$refs.au.autoplay = '';
          this.$refs.au.autoplay = 'autoplay';
          this.$refs.au.controls = '';
          this.$refs.au.controls = 'controls';
        }
      }

      //   var lis = document.getElementsByTagName("li");

      // 获取音乐文件
      //   var arr = ["./audio/one.mp3", "audio/one.mp3"];
      //给li添加点击事件

      //   for (var i = 0; i < lis.length; i++) {
      // console.log(this.arr[i].id);
      // if (this.arr[i].id == i) {
      //   this.musciUrl = this.arr[i].url;
      //   this.textM += this.arr[i].name;
      // }

      // ado.play();
      // lis[i].onclick = function () {
      //   console.log(lis[i]);
      //   for (var i = 0; i < lis.length; i++) {
      //     if (this == lis[i]) {
      //       lis[i].className = "sty";
      //       ado.src = this.arr[i];
      //       ado.play();
      //       //将歌名存储到span标签显示
      //       con.innerHTML = lis[i].innerHTML;
      //       //新建一变量存储当前音乐下标,获取当前音乐会是否播放完毕，播放完毕后实现下标+1操作
      //       var a = i;
      //       ado.onended = function () {
      //         a++;
      //         if (a > lis.length - 1) {
      //           a = 0;
      //         }
      //         for (var j = 0; j < lis.length; j++) {
      //           lis[j].className = "";
      //         }
      //         con.innerHTML = lis[a].innerHTML;
      //         ado.src = this.arr[a];
      //         ado.play();
      //         lis[a].className = "sty";
      //       };
      //     } else {
      //       lis[i].className = "";
      //     }
      //   }

      // };
      //       }
    },
  },
};
</script>

<style>
* {
  padding: 0;
  margin: 0;
}

header,
footer {
  height: 40px;
  line-height: 40px;
  background: orange;
  text-align: center;
}

li {
  height: 50px;
  line-height: 50px;
  border: 1px solid red;
  border-top: none;
  font-size: 15px;
  text-indent: 20px;
  list-style: none;
}

#ado {
  width: 100%;
  height: 80px;
}

.sty {
  background: #fa658d;
}

#app {
  margin-top: 100px;
  margin-left: 600px;
  width: 320px;
}
</style>
